-- Remove all essential data

DELETE FROM `#__virtuemart_configs`;
DELETE FROM `#__virtuemart_adminmenuentries`;
DELETE FROM `#__virtuemart_modules`;
DELETE FROM `#__virtuemart_orderstates`;
DELETE FROM `#__virtuemart_userfields`;
DELETE FROM `#__virtuemart_userfield_values`;