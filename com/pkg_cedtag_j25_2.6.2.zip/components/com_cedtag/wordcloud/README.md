Wordle-like clickable cloud of words in PHP
===============================

Inspired by http://www.wordle.net/

Author:

 * Daniel Barsotti / info [at] dreamcraft [dot] ch

Contributors:

 * jaskra
 * mrahmadt


This source file is subject to the MIT license that is bundled  with this source code in the file LICENSE.
