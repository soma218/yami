<?php

/**
 * @package Component cedTag for Joomla! 2.5
 * @author waltercedric.com
 * @copyright (C) 2012 http://www.waltercedric.com
 * @license GNU/GPL http://www.gnu.org/copyleft/gpl.html
 **/
defined('_JEXEC') or die('Restricted access');?>

<h1><?php echo $this->tag; ?></h1>
<h2><?php echo JText::_($this->message);?></h2>

<!-- CedTag Free Tagging system for Joomla by www.waltercedric.com -->