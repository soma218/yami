/**************** TORTAGS *********************/
/************* version 1.3.6 *****************/
/**** Joomla 1.6, Joomla 1.7, Joomla 2.5 ****/
/*************** Joomla 3.0 ****************/


This is a unique free component to create tag system on your Joomla! site. 
Through this component, and a few plug-ins you can add tags to virtually 
all components using the editor in their fields. 

[Files:]
com_tortags.zip
mod_tortags_often_clouds.zip
plg_content_tortags.zip
plg_editors-xtd_tortags.zip
plg_search_tortags.zip
plg_system_tortags.zip
plg_finder_tortags.zip

[Install:]

 Extensions-> Extension Manager: Install
 "Browse"
 Select component(module)
 "Open"
 "Upload & Install"

The same as install component above to be installed four plugins.
After that, need publish all plugins: 1. Filter->"tortags" 2. Check all 3. Publish

[Configuration:]
Next, you must specify with which components will work Tortags. Specify the basic configuration of a component. 

[Add new tags:]
If everything was configured correctly, the field appears in the bottom of editor to add new tags.
    1. Enter a new tag
    2. Click on "add tag"
    3. After, place the cursor at the location where you want to display tags, and then click "TorTags"
Note: The latest versions(2.5.0+) includes the ability to include the automatic insertion of articles without (3) clicking on the button TorTags.

-------------------------------------------------
				support@tormix.com
-------------------------------------------------
-				http://tormix.com				-
-------------------------------------------------