-- $Id: uninstall.mysql.utf8.sql 62 2010-11-28 16:08:16Z chdemko $ 
DROP TABLE IF EXISTS `#__fieldsattach`;
DROP TABLE IF EXISTS `#__fieldsattach_groups`;
DROP TABLE IF EXISTS `#__fieldsattach_values`;
DROP TABLE IF EXISTS `#__fieldsattach_images`;
DROP TABLE IF EXISTS `#__fieldsattach_categories_values`; 
