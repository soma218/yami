ALTER TABLE  `#__fieldsattach` ADD `searchable` tinyint(1) AFTER  `published` ; 
