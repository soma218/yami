ALTER TABLE  `#__fieldsattach_groups` ADD `description` text AFTER  `title` ; 
