ALTER TABLE  `#__fieldsattach` ADD `required` tinyint(1) AFTER  `published` ; 
