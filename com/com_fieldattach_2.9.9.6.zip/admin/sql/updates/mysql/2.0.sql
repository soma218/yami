ALTER TABLE  `#__fieldsattach_groups` ADD `articlesid` varchar(255) AFTER  `catid` ; 
