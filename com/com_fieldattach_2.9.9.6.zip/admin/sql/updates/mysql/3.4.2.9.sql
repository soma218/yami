ALTER TABLE  `#__fieldsattach_groups` ADD `note` varchar(150) AFTER  `title` ; 
