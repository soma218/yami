ALTER TABLE  `#__fieldsattach_groups` ADD `position` varchar(255) AFTER  `description` ; 
