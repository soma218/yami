<div id="cel_[FIELD_ID]">
    <span class="title">[TITLE]</span>
    <span class="value">[VALUE]</span>
</div>

 
 
