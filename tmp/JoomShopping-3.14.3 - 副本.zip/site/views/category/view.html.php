<?php
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport( 'joomla.application.component.view');

class JshoppingViewCategory extends JView
{
    function display($tpl = null){
        parent::display($tpl);
	}
}
?>