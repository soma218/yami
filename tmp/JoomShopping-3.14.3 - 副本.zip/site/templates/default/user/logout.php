<?php defined('_JEXEC') or die(); ?>
<div class="jshop">
    <h1><?php print _JSHOP_LOGOUT ?></h1>
    <input type="button" value="<?php print _JSHOP_LOGOUT ?>" onclick="location.href='<?php print SEFLink("index.php?option=com_jshopping&controller=user&task=logout"); ?>'" />
</div>