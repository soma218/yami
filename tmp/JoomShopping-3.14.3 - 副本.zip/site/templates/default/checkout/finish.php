<?php defined('_JEXEC') or die(); ?>
<?php if (!empty($this->text)){?>
<?php echo $this->text;?>
<?php }else{?>
<p><?php print _JSHOP_THANK_YOU_ORDER?></p>
<?php }?>