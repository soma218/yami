<?php defined('_JEXEC') or die(); ?>
<script type="text/javascript">
function check_pm_sofortueberweisung(){
    jQuery('#payment_form').submit();
}
</script>