<?php 
	defined('_JEXEC') or die();
	print $this->code;
?>