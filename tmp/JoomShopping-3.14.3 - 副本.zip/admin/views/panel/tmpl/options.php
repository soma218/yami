<?php defined('_JEXEC') or die(); ?>
<table width = "100%">
<tr>
    <td>
        <div id = "cpanel">
        <?php displayOptionPanelIco(); ?>
        </div>
    </td>
</tr>
</table>