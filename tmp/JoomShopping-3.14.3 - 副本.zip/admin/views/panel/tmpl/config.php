<?php defined('_JEXEC') or die(); ?>
<table width = "100%">
<tr>
    <td>
        <div id = "cpanel">
        <?php displayConfigPanelIco();?>
        </div>
    </td>
</tr>
</table>